 package tools;
 public class ImportSettings
{
	public String sourcePath;
	public String successPath;
	public String errorPath;
}