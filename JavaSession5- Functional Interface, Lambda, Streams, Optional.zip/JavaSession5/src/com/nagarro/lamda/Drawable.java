package com.nagarro.lamda;

interface Drawable{  
    void draw();  
}  
