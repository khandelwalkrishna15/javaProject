package com.nagarro.lamda;

interface Design {
	public void draw();
	public void paint();
}

public class AnonymousClassMultipleMethods {
	public static void main(String[] args) {
		int width = 10;

		Design d = new Design() {
			public void draw() {
				System.out.println("Drawing " + width);
			}

			public void paint() {
				System.out.println("Painting " + width);
			}
//			public void pain2t() {
//				System.out.println("Painting " + width);
//			}
		};
		d.draw();
		d.paint();
		//d.paint();
	}
}


