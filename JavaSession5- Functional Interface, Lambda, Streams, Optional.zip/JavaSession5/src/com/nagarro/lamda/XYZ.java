//package com.nagarro.lamda;
//
//public class XYZ extends AnonymousClassMultipleMethods{
//	AnonymousClassMultipleMethods d=new AnonymousClassMultipleMethods();
//	d.draw();
//	d.paint();
//}