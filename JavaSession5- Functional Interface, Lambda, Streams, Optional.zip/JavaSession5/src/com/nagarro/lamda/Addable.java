package com.nagarro.lamda;

interface Addable {
	int add(int a, int b);
}