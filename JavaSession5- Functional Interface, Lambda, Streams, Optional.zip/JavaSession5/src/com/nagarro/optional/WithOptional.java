package com.nagarro.optional;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class WithOptional {
	public static void main(String[] args) {
		String[] words = new String[10];
		words[5] = "hello";
		Optional<String> checkNull = Optional.ofNullable(words[5]);

		// Check if value is Present
		System.out.println("Value is present: " + checkNull.isPresent());

		// Get the value if present
		if (checkNull.isPresent()) {
			System.out.println("Present value is " + checkNull.get());
		}

		// Return result of supplying function if null
		Consumer<String> consumer = (s) -> {
			int a = 10;
			int b = 20;
			int sum = a + b;
			System.out.println(s + " " + sum);
		};
		checkNull.ifPresent(consumer);

		// Return string if null
		System.out.println(checkNull.orElse("Word is null"));

		// Return result of supplying function if null
		Supplier<String> supplier = () -> {
			int a = 10;
			int b = 20;
			int sum = a + b;
			return "NAGP " + sum;
		};
		System.out.println(checkNull.orElseGet(supplier));
	}
}
