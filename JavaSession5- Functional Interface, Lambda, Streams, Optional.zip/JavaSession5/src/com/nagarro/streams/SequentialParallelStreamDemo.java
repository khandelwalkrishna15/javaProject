package com.nagarro.streams;

import java.util.Arrays;
import java.util.List;

public class SequentialParallelStreamDemo {
	public static void main(String[] args) {

		List<String> list = Arrays.asList("H", "E", "L", "L", "O");

		// Sequential Stream
		System.out.print("Sequential Order: ");
		list.stream().forEach(System.out::print);

		// Parallel Stream
		System.out.print("\nParallel Order: ");
		list.parallelStream().forEach(System.out::print);
	}
}
