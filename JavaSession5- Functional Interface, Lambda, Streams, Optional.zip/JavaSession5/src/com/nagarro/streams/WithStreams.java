package com.nagarro.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class WithStreams {
	public static void main(String[] args) {
		List<Product> productsList = new ArrayList<Product>();

		// Adding Products
		productsList.add(new Product(1, "HP Laptop", 25000));
		productsList.add(new Product(2, "Dell Laptop", 30000));
		productsList.add(new Product(3, "Lenevo Laptop", 28000));
		productsList.add(new Product(4, "Sony Laptop", 28000));
		productsList.add(new Product(5, "Apple Laptop", 90000));
		
		List<Integer> productPriceList2 = productsList.stream().filter(p -> p.price < 30000)// filtering data
				.map(p -> p.price) // fetching price
				.collect(Collectors.toList()); // collecting as list
		System.out.println("Prices less than 30k are: " + productPriceList2);

		// Collected as Set
		Set<Integer> productPriceList3 = productsList.stream().filter(p -> p.price < 30000)// filtering data
				.map(p -> p.price) // fetching price
				.collect(Collectors.toSet()); // collecting as list
		System.out.println("Prices less than 30k are: " + productPriceList3);

		// Filtering and Iterating the products
		System.out.print("Products' Names whose prices are less than 30k are: ");
		productsList.stream().filter(product -> product.price < 30000)
				.forEach(product -> System.out.print(product.name + " , "));

		// Get Max Product price
		Product productA = productsList.stream().max((product1, product2) -> product1.price > product2.price ? 1 : -1)
				.get();
		System.out.println("\nMaximum price is: " + productA.price);

		// Get Min Product price
		Product productB = productsList.stream().min((product1, product2) -> product1.price > product2.price ? 1 : -1)
				.get();
		System.out.println("Minimum price is: " + productB.price);

		// Reduce
		Integer totalPrice = productsList.stream().map(product -> product.price).reduce(0, (sum, price) -> sum + price); 
		System.out.println("Total Price of all products is: " + totalPrice);

		// Sort
		List<Integer> productsList4 = productsList.stream().map(p -> p.price).sorted().collect(Collectors.toList());
		System.out.println("Products in sorted order are: " + productsList4);

		// Limit
		List<Integer> productsList5 = productsList.stream().map(p -> p.price).sorted().limit(2)
				.collect(Collectors.toList());
		System.out.println("First 2 Products in sorted order are: " + productsList5);

		// Skip
		List<Integer> productsList6 = productsList.stream().map(p -> p.price).sorted().skip(1)
				.collect(Collectors.toList());
		System.out.println("Products in sorted order after skipping 1 product are: " + productsList6);
	}

}
