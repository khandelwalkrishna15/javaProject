package com.nagarro.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class ProductNew {
	int id;
	String name;
	int price;

	public ProductNew(int id, String name, int price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
}

public class Exercise {
	public static void main(String[] args) {
		List<ProductNew> productsList = new ArrayList<ProductNew>();

		// Adding Products
		productsList.add(new ProductNew(1, "HP Laptop", 25000));
		productsList.add(new ProductNew(2, "Dell Laptop", 30000));
		productsList.add(new ProductNew(3, "Lenevo Laptop", 28000));
		productsList.add(new ProductNew(4, "Sony Laptop", 28000));
		productsList.add(new ProductNew(5, "Apple Laptop", 90000));
		
		//List<ProductNew> sortedProductsList = productsList.stream().sorted().forEach(product->System.out.println(product));;
		productsList.stream().map(p->p.name).sorted().forEach(product->System.out.println(product));
	}

}
