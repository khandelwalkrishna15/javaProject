package com.nagarro.functionalinterface;

interface BonusCalculator {
	
	void calculateBonus(int x);
	
	//void calculateBonus2(int x);
	
	default void greetMessage() {
		System.out.println("Default Method executed");
	}
	
	static void verify(){
		System.out.println("Static Method executed");
	}

}
