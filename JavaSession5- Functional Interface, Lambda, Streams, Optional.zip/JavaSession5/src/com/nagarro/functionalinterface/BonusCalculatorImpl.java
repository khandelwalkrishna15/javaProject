package com.nagarro.functionalinterface;

public class BonusCalculatorImpl implements BonusCalculator {

	@Override
	public void calculateBonus(int x) {
		System.out.println("Bonus is: " + x);

	}

	@Override
	public void greetMessage() {
		BonusCalculator.super.greetMessage();
		System.out.println("Default Method executed from Implementation Class");
	}

	//@Override
	static void verify(){
		System.out.println("Static Method executed");
	}

	public static void main(String[] args) {

		BonusCalculatorImpl bonusCalculator = new BonusCalculatorImpl();

		bonusCalculator.greetMessage(); // calling default method
		bonusCalculator.calculateBonus(10000); // calling abstract method
		BonusCalculator.verify(); // calling static method
	}

}
